function R0=cal_R_power(y_ini,C)
    global p;
    p=para_Vaccine;
    fai=2.4e-5;
    h2=0.53;
    tspan=[0:0.01:30];
    [t,R] = ode23t(@Vaccine_model,tspan,y_ini);
    P=1-exp(-fai*R(:,1).^h2);
    S=trapz(t,P);
    R0=C*S;
end