%��Ⱦ����ģ��
clear all;clc;
global p;
p=para_Vaccine;
color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;

y0=[1;1;0];
tspan=[0:1:700];
[t,R] = ode23t(@Vaccine_model,tspan,y0);

Infect_time=[90:1:500];
MVL=[];
RT=[];
for Infect_t=Infect_time
    y_i=R(Infect_t,:);
    y_i(1)=1;
    p=para_Vaccine;
    tspan=[Infect_t:1:Infect_t+30];
    [t_i,R_i] = ode23t(@Vaccine_model,tspan,y_i);
    t_new=[t(1:Infect_t-1);t_i];R_new=[R([1:Infect_t-1],:);R_i];
    [mVL_t,Ht_t]=cal_VL_Ht(y_i);
    MVL=[MVL,mVL_t];
    RT=[RT,Ht_t];
end
%%
figure;
subplot(1,2,1);
plot(Infect_time,log10(MVL),'color',color_e,'linewidth',2);
hold on;
x=[0];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
xlabel('time (day)');
ylabel('MVL Log10 (/ml)');
axis([-20 500 2 8])
adjust_fig;

subplot(1,2,2);
plot(Infect_time,RT,'color',color_e,'linewidth',2);
hold on;
x=[0];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
xlabel('time (day)');
ylabel('RT (day)');
axis([-20 500 6 17])
adjust_fig;

set(gcf,'position',[500 500 800 320])