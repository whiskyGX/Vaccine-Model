function output=para_Vaccine_V1000()
p=zeros(12,1);
p(1)=3.3;%r
p(2)=1.82318445e-02;%gamma !!
p(3)=1;%k
p(4)= 2.337;%fai
p(5)=1e3;%V1
p(6)=250;% Em 
p(7)=2.36748442e-02;%beta
p(8)=0.0118;%q
p(9)=7.08786894e-03;%alpha  !!
p(10)=1.88792250e-02;%epi
p(11)=100;%Mm !!
p(12)=16.554528988731803*3;%vaccine dose
p(13)=1/0.3769501031016696;%E scale
output=p;
end