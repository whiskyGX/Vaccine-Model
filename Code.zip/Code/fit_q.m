%Calculate q E
clc;clear all;
delta=182-28;
GMT=[45.8,9.2;
    74.2,13.6;
    27.4,3.9;
    30.4,4.7;
    49.7,10;
    51.9,10.1;
    45.9,6.8;
    71,7.1];

q=log(GMT(:,1)./GMT(:,2))/delta;
mean(q)