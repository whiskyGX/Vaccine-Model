% Vaccine process
%vaccine
%��Ⱦ����ģ��
clear all;clc; 
global p;
p=para_Vaccine_V100000;
p(1)=0;

color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Vaccine_Virus=p(12);%�����е�Ч������Ŀ
scale=p(13);
Vaccine_I1=21;%һ������ 14  28
Vaccine_I2=182;%�������� 61 243

y0=[Vaccine_Virus;0;0];%��һ��
tspan=[0:1:Vaccine_I1-1];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

y1=R_1(end,:);%�ڶ���
y1(1)=y1(1)+Vaccine_Virus;
tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
[t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

y2=R_2(end,:);%������
y2(1)=y2(1)+Vaccine_Virus;
tspan=[Vaccine_I1+Vaccine_I2:400];
[t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
t=[t1;t2;t3];R=[R_1;R_2;R_3];

figure;
subplot(1,3,1)
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[300,300,300]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
plot(t,log10(R(:,1)),'linewidth',2,'color',color_r);

%set(gca,'YScale','log');

xlabel('time (day)');
ylabel('VL in Log10 (/mL)');
title('Vaccine')
axis([-20 400 0 5])
adjust_fig;

subplot(1,3,2)
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[300,300,300]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
plot(t,R(:,2),'linewidth',2,'color',color_e);

plot(t,R(:,3),'linewidth',2,'color',color_m);
adjust_fig;
xlabel('time (day)');
legend('E','M')
axis([-20 400 0 100])

set(gcf,'position',[500 500 800 320])
%
subplot(1,3,3)
plot(R(:,2),R(:,3),'b','linewidth',2);
hold on;
scatter(R(21,2),R(21,3),50,'filled');
scatter(R(1,2),R(1,3),50,'filled');
scatter(R(21+182,2),R(21+182,3),50,'filled');
adjust_fig;
xlabel('E (A.U.)');
ylabel('M (A.U.)');
%axis([0 50 0 100]);
set(gcf,'position',[0 0 1300 320])


%% 3D
%{
figure;
plot3(R(:,2),R(:,3),R(:,1),'linewidth',2);
hold on;
plot3(R(:,2),100*ones(length(R),1),R(:,1),'linewidth',2);
plot3(100*ones(length(R),1),R(:,3),R(:,1),'linewidth',2);
set(gca,'ZScale','log');
zlabel('VL in Log10 /swab');
xlabel('E');
ylabel('M');
axis([0 100 0 100 0.4 1e3])
adjust_fig;
%}
