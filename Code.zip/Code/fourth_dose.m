% fourth dose
clear all;clc; 
global p;
p=para_Vaccine;
p(1)=0;

color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Vaccine_Virus=p(12);%�����е�Ч������Ŀ
scale=p(13);
Vaccine_I1=21;%һ������ 14  28
Vaccine_I2=182;%�������� 61 243
Vaccine_I3=182;

y0=[Vaccine_Virus;0;0];%��һ��
tspan=[0:1:Vaccine_I1-1];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

y1=R_1(end,:);%�ڶ���
y1(1)=y1(1)+Vaccine_Virus;
tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
[t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

y2=R_2(end,:);%������
y2(1)=y2(1)+Vaccine_Virus;
tspan=[Vaccine_I1+Vaccine_I2:1:Vaccine_I1+Vaccine_I2+Vaccine_I3-1];
[t3,R_3] = ode23t(@Vaccine_model,tspan,y2);

y3=R_3(end,:);%������
y3(1)=y3(1)+Vaccine_Virus;
tspan=[Vaccine_I1+Vaccine_I2+Vaccine_I3:1:1000];
[t4,R_4] = ode23t(@Vaccine_model,tspan,y3);
t=[t1;t2;t3;t4];R=[R_1;R_2;R_3;R_4];

figure;
subplot(1,3,1)
plot(t,R(:,2),'linewidth',2,'color',color_e);
hold on;
plot(t,R(:,3),'linewidth',2,'color',color_m);
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2,Vaccine_I1+Vaccine_I2+Vaccine_I3];
y=[300,300,300,300]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
adjust_fig;
xlabel('time (day)');
legend('E','M')
axis([-20 700 0 100])



%%
Infect_time=[1:1:Vaccine_I1+Vaccine_I2+Vaccine_I3+300];
MVL=[];
RT=[];
for Infect_t=Infect_time
    y_i=R(Infect_t,:);
    y_i(1)=1;
    p=para_Vaccine;
    tspan=[Infect_t:1:Infect_t+30];
    [t_i,R_i] = ode23t(@Vaccine_model,tspan,y_i);
    t_new=[t(1:Infect_t-1);t_i];R_new=[R([1:Infect_t-1],:);R_i];
    [mVL_t,Ht_t]=cal_VL_Ht(y_i);
    MVL=[MVL,mVL_t];
    RT=[RT,Ht_t];
end
subplot(1,3,3)
plot(Infect_time,log10(MVL),'color',color_e,'linewidth',2);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2,Vaccine_I1+Vaccine_I2+Vaccine_I3];
y=[10,10,10,10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('MVL Log10 (/ml)');
axis([-20 700 3 7])
adjust_fig;

%% predict antibody titer
subplot(1,3,2)
plot(t,R(:,2)*scale,'color',color_e,'linewidth',2);
hold on;
scatter(Vaccine_I1+28,R(find(t==Vaccine_I1+28),2)*2.5,'filled');
scatter(Vaccine_I1+Vaccine_I2+28,R(find(t==Vaccine_I1+Vaccine_I2+28),2)*2.5,'filled');
scatter(Vaccine_I1+Vaccine_I2+Vaccine_I3+28,R(find(t==Vaccine_I1+Vaccine_I2+Vaccine_I3+28),2)*2.5,'filled');

x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2,Vaccine_I1+Vaccine_I2+Vaccine_I3];
y=[1e4,1e4,1e4,1e4]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('GMTs');
axis([-20 700 0 200])
set(gcf,'position',[500 500 1300 320])
adjust_fig;