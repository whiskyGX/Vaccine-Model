function dydt=Vaccine_model(t,y)
    global p;
    if y(1)<0.5
        y(1) = 0;
    end
    %[r,gamma,k,fai,V1,Em,beta,q,alpha,epi]=p;
    r=p(1);gamma=p(2);k=p(3);fai=p(4);V1=p(5);Em=p(6);beta=p(7);q=p(8);
    alpha=p(9);epi=p(10);Mm=p(11);
    dydt=zeros(3,1);
    dydt(1)=r*y(1)-gamma*y(1)*y(2); %Virus
    dydt(2)=(k+fai*y(2))*y(1)/(y(1)+V1)*(1-y(2)/Em)+beta*y(1)*y(3)-q*y(2); %Effector
    %dydt(3)=p(6)*y(2)*p(7)/(y(1)+p(7))*(1-y(3)/p(10))-p(8)*y(1)*y(3)-p(9)*y(3); %Memory
    dydt(3)=(alpha*y(2)+epi*y(3))*(1-y(3)/Mm)-beta*y(1)*y(3);
end