function dydt=memory_decay(t,y)
    dydt=zeros(3,1);
    dydt(1)=0; %Memory B
    dydt(2)=-0.0059*y(2); %Memory CD4+
    dydt(3)=-0.0040*y(3); %Memory CD8+
    y(y<1e-9) = 0;
end