%optimize dose
%��Ⱦ����ģ��
clear all;clc; 
global p;
p=para_Vaccine;
p(1)=0;

color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Vaccine_Virus=p(12);%�����е�Ч������Ŀ 3ug
scale=p(13);
Vaccine_I1=21;%һ������ 14  28
Vaccine_I2=182;%�������� 61 243

y0=[Vaccine_Virus;0;0];%��һ��
tspan=[0:1:Vaccine_I1-1];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

y1=R_1(end,:);%�ڶ���
y1(1)=y1(1)+Vaccine_Virus;
tspan=[Vaccine_I1:1:500];
[t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

%y2=R_2(end,:);%������
%y2(1)=Vaccine_Virus;
%tspan=[Vaccine_I1+Vaccine_I2:700];
%[t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
t=[t1;t2];R=[R_1;R_2];

loc=find(R(:,3)>50);
t_half_memory=t(loc(1));

figure;
plot(t,R(:,2),'linewidth',2,'color',color_e);
hold on;
plot(t,R(:,3),'linewidth',2,'color',color_m);
x=[0,Vaccine_I1];
y=[1e10,1e10]; %5Ϊ��2���yֵ
title('3 ug')
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
adjust_fig;
xlabel('time (day)');
legend('E','M')
axis([-20 400 0 100])

set(gcf,'position',[500 500 380 320])
%%
figure
for dose=[1.5,3,6,9]
    p=para_Vaccine;
    p(1)=0;
    Vaccine_Virus=p(12)/3*dose;%�����е�Ч������Ŀ 3ug
    scale=1/0.4153778747830513;
    Vaccine_I1=21;%һ������ 14  28
    y0=[Vaccine_Virus;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus;
    tspan=[Vaccine_I1:1:500];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);
    t=[t1;t2];R=[R_1;R_2];
    
    subplot(1,2,1)
    
    hold on;
    xlabel('time (day)');ylabel('E (A.U.)');
    adjust_fig;
    x=[0,21];
    y=[300,300]; %5Ϊ��2���yֵ
    stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    plot(t,R(:,2),'linewidth',2,'color',color_e);
    axis([-15 400 0 100])
    
    subplot(1,2,2)
    hold on;
    x=[0,21];
    y=[300,300]; %5Ϊ��2���yֵ
    stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    plot(t,R(:,3),'linewidth',2,'color',color_m);
    xlabel('time (day)');ylabel('M (A.U.)');
    axis([-15 500 0 100])
    adjust_fig;
end
set(gcf,'position',[500 500 800 320])

%%
dose=[1:0.1:30];
t_half_memory=[];
for d=dose
    p=para_Vaccine;
    p(1)=0;

    Vaccine_Virus=p(12)/3*d;%�����е�Ч������Ŀ 3ug
    scale=1/0.4153778747830513;
    Vaccine_I1=21;%һ������ 14  28
    Vaccine_I2=182;%�������� 61 243

    y0=[Vaccine_Virus;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus;
    tspan=[Vaccine_I1:0.1:400];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

    t=[t1;t2];R=[R_1;R_2];

    loc=find(R(:,3)>50);
    t_half_memory=[t_half_memory,t(loc(1))];
end
figure;
plot(dose,t_half_memory,'linewidth',2,'color',color_m);
hold on;
scatter(1.5,t_half_memory(find(dose==1.5)),'filled','o');
scatter(3,t_half_memory(find(dose==3)),'filled');
scatter(6,t_half_memory(find(dose==6)),'filled');
scatter(9,t_half_memory(find(dose==9)),'filled');
ylabel('Memory half-time (day)');
xlabel('Dose (ug)');
set(gcf,'position',[500 500 380 320])
adjust_fig;