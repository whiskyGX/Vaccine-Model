
%% fit
%��Ⱦ����ģ��
clear all;clc; 
load Data_VL.mat;
load('data_memory.mat');
color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Patient=Data_VL.ID14;
global p;
p=para_Vaccine;

y0=[1;0;0];
tspan=[0,300];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);
t=[t1];R=[R_1];
M_scale=844.0233226565001;
PSO=data_memory(:,7);
Spike_memory_B=data_memory(:,17);

figure;
subplot(1,3,1)
plot(t,log10(R(:,1)),'linewidth',2,'color',color_r);
hold on;
%scatter(Patient(:,1),10.^Patient(:,2),30,'filled','k');
%set(gca,'YScale','log');
xlabel('time (day)');
ylabel('VL in Log10 (/ml)');
axis([0 30 0 8])
adjust_fig;

subplot(1,3,3)
plot(t,R(:,2),'linewidth',2,'color',color_e);
hold on;
plot(t,R(:,3),'linewidth',2,'color',color_m);
axis([0 250 0 300])
adjust_fig;
xlabel('time (day)');
legend('E','M')

subplot(1,3,2)
hold on;
scatter(PSO,Spike_memory_B,15,'filled','k');
plot(t,R(:,3)/M_scale,'r','linewidth',2,'color',color_m);

set(gca,'YScale','log');
axis([0 250 0.01 1.1])
adjust_fig;
xlabel('time (day)');
ylabel('Spike-specific memory B (%)');
%title('Fit Memory B');
%legend('Effector Module','Memory Module')

set(gcf,'position',[500 500 1200 320])