clear all;clc; 
global p;
p=para_Vaccine;

y0=[1;0;0];
tspan=[0:1:500];
[t,R] = ode23t(@Vaccine_model,tspan,y0);
figure;
subplot(1,2,1)
plot(t,R(:,1),'linewidth',2);
hold on;
set(gca,'YScale','log');
xlabel('time (day)');
ylabel('VL (/ml)');
axis([0 30 1 10^8])
adjust_fig;

subplot(1,2,2)
plot(t,R(:,2),'linewidth',2);
hold on;
plot(t,R(:,3),'linewidth',2);
adjust_fig;
xlabel('time (day)');
%legend('Effector Module','Memory Module')

set(gcf,'position',[500 500 800 320])

%% �ٴθ�Ⱦ֮��Ĳ�������
max_VL=[];
t_list=t([30:end]);
for i=30:length(t)
    a=cal_VL([0,R(i,2),R(i,3)]);
    max_VL=[max_VL,a];
end
figure;
plot(t_list,max_VL,'linewidth',2)
adjust_fig;
xlabel('time (day)');
ylabel('VL (/ml)')
%%
interval=100;
R_VL=zeros(interval,interval);
E_list=[0:100/interval:100-100/interval];M_list=[0:100/interval:100-100/interval];
i=1;
for E=E_list
    j=1;
    for M=M_list
        R_VL(i,j)=cal_VL([0,E,M]);
        j=j+1;
    end
    i=i+1
end
imagesc(M_list,E_list,log10(R_VL))
colorbar;
adjust_fig;
xlabel('E');
ylabel('M')

