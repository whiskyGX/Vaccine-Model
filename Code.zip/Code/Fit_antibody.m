function Loss=Fit_antibody(Vaccine_Virus,Em,beta,scale)
    global p;
    p=para_Vaccine;
    p(1)=0;
    p(6)=Em;
    p(7)=beta;
    %p(2)=p(2)*100/Em;%gamma 0.0477
    %p(9)=p(9)*100/Em;%alpha 0.01537
    
    List={'C1a','C1b','C2a','C2b'};
    load Data_Vaccine.mat;
    for j=1:4
    Cohort=List{j};%%�Ĵ�
    
    if strcmp(Cohort,'C1a')
    Vaccine_I1=14;%һ������ 14  28
    Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C1b')
    Vaccine_I1=14;%һ������ 14  28
    Vaccine_I2=243;%�������� 61 243
    elseif strcmp(Cohort,'C2a')
    Vaccine_I1=28;%һ������ 14  28
    Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C2b')
    Vaccine_I1=28;%һ������ 14  28
    Vaccine_I2=243;%�������� 61 243
    end
    
    y0=[Vaccine_Virus;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus;
    tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

    y2=R_2(end,:);%������
    y2(1)=y2(1)+Vaccine_Virus;
    tspan=[Vaccine_I1+Vaccine_I2:1:400];
    [t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
    t=[t1;t2;t3];R=[R_1;R_2;R_3];
    
    if strcmp(Cohort,'C1a')
    Data_t=Data_Vaccine_3ug.C1a_14d_2m;
    elseif strcmp(Cohort,'C1b')
    Data_t=Data_Vaccine_3ug.C1b_14d_8m;
    elseif strcmp(Cohort,'C2a')
    Data_t=Data_Vaccine_3ug.C2a_28d_2m;
    elseif strcmp(Cohort,'C2b')
    Data_t=Data_Vaccine_3ug.C2b_28d_8m;
    end
    for m=1:3
        day=Data_t(m+1,1);
        d1=Data_t(m+1,2)/scale;%real data
        d2=R(find(t==day),2);%cal 
        Dis(j,m)=(d2-d1)^2;
    end
    end
    
    
    for j=1:4
    Cohort=List{j};%%�Ĵ�
    
    if strcmp(Cohort,'C1a')
    Vaccine_I1=14;%һ������ 14  28
    Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C1b')
    Vaccine_I1=14;%һ������ 14  28
    Vaccine_I2=243;%�������� 61 243
    elseif strcmp(Cohort,'C2a')
    Vaccine_I1=28;%һ������ 14  28
    Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C2b')
    Vaccine_I1=28;%һ������ 14  28
    Vaccine_I2=243;%�������� 61 243
    end
    
    y0=[Vaccine_Virus*2;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus*2;
    tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

    y2=R_2(end,:);%������
    y2(1)=y2(1)+Vaccine_Virus*2;
    tspan=[Vaccine_I1+Vaccine_I2:1:400];
    [t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
    t=[t1;t2;t3];R=[R_1;R_2;R_3];
    
    if strcmp(Cohort,'C1a')
    Data_t=Data_Vaccine_6ug.C1a_14d_2m;
    elseif strcmp(Cohort,'C1b')
    Data_t=Data_Vaccine_6ug.C1b_14d_8m;
    elseif strcmp(Cohort,'C2a')
    Data_t=Data_Vaccine_6ug.C2a_28d_2m;
    elseif strcmp(Cohort,'C2b')
    Data_t=Data_Vaccine_6ug.C2b_28d_8m;
    end
    for m=1:3
        day=Data_t(m+1,1);
        d1=Data_t(m+1,2)/scale;%real data
        d2=R(find(t==day),2);%cal 
        Dis2(j,m)=(d2-d1)^2;
    end
    end
    %Dis2(3,3)=0;
    D=[Dis;Dis2];
    Loss=sqrt(sum(sum(D)));
end