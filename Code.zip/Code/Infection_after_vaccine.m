%Infection after vaccine
% Vaccine process
%vaccine
%��Ⱦ����ģ��
clear all;clc; 
global p;
p=para_Vaccine;
p(1)=0;

color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Vaccine_Virus=p(12);%�����е�Ч������Ŀ
scale=p(13);
Vaccine_I1=21;%һ������ 14  28
Vaccine_I2=182;%�������� 61 243

y0=[Vaccine_Virus;0;0];%��һ��
tspan=[0:1:Vaccine_I1-1];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

y1=R_1(end,:);%�ڶ���
y1(1)=y1(1)+Vaccine_Virus;
tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
[t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

y2=R_2(end,:);%������
y2(1)=y2(1)+Vaccine_Virus;
tspan=[Vaccine_I1+Vaccine_I2:1:700];
[t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
t=[t1;t2;t3];R=[R_1;R_2;R_3];
%{
figure;
subplot(1,2,1)
plot(t,R(:,1),'linewidth',2,'color',color_r);
hold on;
set(gca,'YScale','log');
xlabel('time (day)');
ylabel('VL in Log10 (ml)');
title('Vaccine')
axis([0 400 1 10^5])
adjust_fig;

subplot(1,2,2)
plot(t,R(:,2),'linewidth',2,'color',color_e);
hold on;
plot(t,R(:,3),'linewidth',2,'color',color_m);
adjust_fig;
xlabel('time (day)');
legend('E','M')
axis([0 400 0 100])

set(gcf,'position',[500 500 800 320])
%}
%% Infection;
%Infect_t=Vaccine_I1+60;%���������60���Ⱦ
Infect_t=Vaccine_I1+Vaccine_I2+60;%���������60���Ⱦ
y_i=R(Infect_t,:);
y_i(1)=1;
p=para_Vaccine;
tspan=[Infect_t:1:Infect_t+30];
[t_i,R_i] = ode23t(@Vaccine_model,tspan,y_i);
t_new=[t(1:Infect_t-1);t_i];R_new=[R([1:Infect_t-1],:);R_i];

[mVL,Ht]=cal_VL_Ht(y_i);
%{
figure;
subplot(1,2,1)
plot(t_new,log10(R_new(:,1)),'linewidth',2,'color',color_r);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[1e10,1e10,1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);

x=[Infect_t];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
xlabel('time (day)');
ylabel('VL in Log10 (/ml)');
title(['mVL=',num2str(mVL),'  Ht=',num2str(Ht)])
axis([-2 Vaccine_I1+Infect_t+30 0 7])
adjust_fig;

subplot(1,2,2)
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[1e10,1e10,1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
x=[Infect_t];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
plot(t_new,R_new(:,2),'linewidth',2,'color',color_e);

plot(t_new,R_new(:,3),'linewidth',2,'color',color_m);
adjust_fig;
xlabel('time (day)');
axis([-2 Infect_t+30 0 300])
%legend('Effector Module','Memory Module')

set(gcf,'position',[500 500 800 320])
%}
%% Infection;
Infect_time=[1:1:Vaccine_I1+Vaccine_I2+365];
MVL=[];
RT=[];
for Infect_t=Infect_time
    y_i=R(Infect_t,:);
    y_i(1)=1;
    p=para_Vaccine;
    tspan=[Infect_t:1:Infect_t+30];
    [t_i,R_i] = ode23t(@Vaccine_model,tspan,y_i);
    t_new=[t(1:Infect_t-1);t_i];R_new=[R([1:Infect_t-1],:);R_i];
    [mVL_t,Ht_t]=cal_VL_Ht(y_i);
    MVL=[MVL,mVL_t];
    RT=[RT,Ht_t];
end
figure;
subplot(1,2,1);
plot(Infect_time,log10(MVL),'color',color_e,'linewidth',2);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[9,9,9]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('MVL Log10 (/ml)');
%set(gca,'YScale','log');
axis([-20 500 3 8])
adjust_fig;

subplot(1,2,2);
plot(Infect_time,RT,'color',color_e,'linewidth',2);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[1e7,1e7,1e7]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('RT (day)');
axis([-20 500 6 17])
adjust_fig;
set(gcf,'position',[500 500 800 320])



%% Infection compare
Infect_t=[Vaccine_I1+60,Vaccine_I1+Vaccine_I2+60];
figure;
subplot(1,2,1)
hold on;
for k=1:3
    if k==1
        y_i=[1,0,0];
    elseif k==2
        y_i=R(Infect_t(1),:);%�ڶ�������60���Ⱦ
        y_i(1)=1;
    elseif k==3
        y_i=R(Infect_t(2),:);%�ڶ�������60���Ⱦ
        y_i(1)=1;
    end
    tspan=[0,30];
    [t_new,R_new] = ode23t(@Vaccine_model,tspan,y_i);
    [mVL,Ht]=cal_VL_Ht(y_i);
    if k==1
       plot(t_new,log10(R_new(:,1)),'linewidth',2,'color',color_r);
    elseif k==2
        plot(t_new,log10(R_new(:,1)),'-.','linewidth',2,'color',color_r);
    elseif k==3
        plot(t_new,log10(R_new(:,1)),':','linewidth',2,'color',color_r);
    end
end
x=[0];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
axis([-2 30 0 8])
xlabel('time (day)');
ylabel('VL in Log10 (/ml)');
adjust_fig;

%% e compare
Infect_t=[Vaccine_I1+60,Vaccine_I1+Vaccine_I2+60];
subplot(1,2,2)
hold on;
for k=1:3
    if k==1
        y_i=[1,0,0];
    elseif k==2
        y_i=R(Infect_t(1),:);
        y_i(1)=1;
    elseif k==3
        y_i=R(Infect_t(2),:);
        y_i(1)=1;
    end
    tspan=[0,30];
    [t_new,R_new] = ode23t(@Vaccine_model,tspan,y_i);
    [mVL,Ht]=cal_VL_Ht(y_i);
    if k==1
       plot(t_new,R_new(:,2),'linewidth',2,'color',color_e);
    elseif k==2
        plot(t_new,R_new(:,2),'-.','linewidth',2,'color',color_e);
    elseif k==3
        plot(t_new,R_new(:,2),':','linewidth',2,'color',color_e);
    end
end
x=[0];
y=[1e10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[7 7 7]/255,'linewidth',2);
axis([-1 8 0 320])
%set(gca,'YScale','log');
xlabel('time (day)');
ylabel('E (A.U.)');
adjust_fig;
set(gcf,'position',[500 500 800 320])