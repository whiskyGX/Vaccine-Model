%��Ⱦ����ģ��
clear all;clc; 
load Data_VL.mat;
Patient=Data_VL.ID14;
global p;
p=para_Vaccine;
color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
y0=[1;0;0];
tspan=[0,300];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);
t=[t1];R=[R_1];
[mVL,Ht]=cal_VL_Ht(y0);
figure;
subplot(1,2,1)
plot(t,log10(R(:,1)),'linewidth',2,'color',color_r);
hold on;
scatter(Patient(:,1),10.^Patient(:,2),30,'filled');
%set(gca,'YScale','log');
xlabel('time (day)');
ylabel('VL in Log10 (/ml)');
%title(['mVL=',num2str(mVL),'  Heal_t=',num2str(Ht)])
axis([-2 30 0 8])
adjust_fig;

subplot(1,2,2)
plot(t,R(:,2),'linewidth',2,'color',color_e);
hold on;
plot(t,R(:,3),'linewidth',2,'color',color_m);
adjust_fig;
xlabel('time (day)');
%legend('Effector Module','Memory Module')

set(gcf,'position',[500 500 800 320])
%%
figure;
plot3(R(:,2),R(:,3),log10(R(:,1)),'b','linewidth',2);
hold on;
plot3(R(:,2),120*ones(length(R),1),log10(R(:,1)),'--b','linewidth',2);
plot3(350*ones(length(R),1),R(:,3),log10(R(:,1)),'--b','linewidth',2);
plot3(R(:,2),R(:,3),zeros(length(R))-2,'--b','linewidth',2);
scatter3(R(1,2),R(1,3),log10(R(1,1)),80,'k','filled');
scatter3(R(1,2),120*ones(1,1),log10(R(1,1)),80,'k','filled');
scatter3(350*ones(1,1),R(1,3),log10(R(1,1)),80,'k','filled');
scatter3(R(1,2),R(1,3),zeros(1)-2,80,'k','filled');
%set(gca,'ZScale','log');
zlabel('VL in Log10 (/mL)');
xlabel('E (A.U.)');
ylabel('M (A.U.)');
axis([-20 350 -10 120 -2 7])
adjust_fig;
grid on;