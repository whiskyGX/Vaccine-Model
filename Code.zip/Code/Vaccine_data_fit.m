%vaccine
%��Ⱦ����ģ��
clear all;clc; 
Vaccine_Virus=101.41438985815718*3;%�����е�Ч������Ŀ
Em=250;
beta=7.71744108e-02;
scale=1/0.4153778747830513;
para_Iteration=[Vaccine_Virus,Em,beta,scale];
Loss=zeros(1,2);
Loss(1)=Fit_antibody(Vaccine_Virus,Em,beta,scale)

%{
para_save=[];
for j=1:5
    j
N=1000;
t_r=lhsdesign(N,3);
Loss=[100 0];
for i=1:N
    %Em=t_r(i,1)*150+200;%[200 350]
    Em=280.0;
    beta=t_r(i,2)*0.01+0.001;%[0.001,0.01]
    %beta=0.0037;%[1e-2,1e-4]
    Vaccine_Virus=t_r(i,3)*400+200;%[200,600]
    %Vaccine_Virus=500;
    scale=1/0.4153778747830513;%2-3
    %scale=2.5;
    Loss(2)=Fit_antibody(Vaccine_Virus,Em,beta,scale);
    if Loss(2)<Loss(1)
        Loss(1)=Loss(2);
        para_Iteration=[Vaccine_Virus,Em,beta,scale];
        %Loss(1);
    end
end
para_save=[para_save;para_Iteration];
end
%}
%%
clear all;clc; 
global p;
p=para_Vaccine_V100000;
p(1)=0;
color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
Vaccine_Virus=p(12);
scale=p(13);

load Data_Vaccine.mat;
List={'C1a','C1b','C2a','C2b'};
figure;
for j=1:4
    Cohort=List{j};%%�Ĵ�
    subplot(2,4,j);
    if strcmp(Cohort,'C1a')
        Vaccine_I1=14;%һ������ 14  28
        Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C1b')
        Vaccine_I1=14;%һ������ 14  28
        Vaccine_I2=243;%�������� 61 243
    elseif strcmp(Cohort,'C2a')
        Vaccine_I1=28;%һ������ 14  28
        Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C2b')
        Vaccine_I1=28;%һ������ 14  28
        Vaccine_I2=243;%�������� 61 243
    end
    y0=[Vaccine_Virus;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus;
    tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

    y2=R_2(end,:);%������
    y2(1)=y2(1)+Vaccine_Virus;
    tspan=[Vaccine_I1+Vaccine_I2:1:400];
    [t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
    t=[t1;t2;t3];R=[R_1;R_2;R_3];
    
    if strcmp(Cohort,'C1a')
        Data_t=Data_Vaccine_3ug.C1a_14d_2m;
    elseif strcmp(Cohort,'C1b')
        Data_t=Data_Vaccine_3ug.C1b_14d_8m;
    elseif strcmp(Cohort,'C2a')
        Data_t=Data_Vaccine_3ug.C2a_28d_2m;
    elseif strcmp(Cohort,'C2b')
        Data_t=Data_Vaccine_3ug.C2b_28d_8m;
    end
    hold on;
    if strcmp(Cohort,'C1a')
        Data_t=Data_Vaccine_3ug.C1a_14d_2m;
        x=[0,14,14+61];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
        title('C1a-14d-2m');
    elseif strcmp(Cohort,'C1b')
        Data_t=Data_Vaccine_3ug.C1b_14d_8m;
        title('C1b-14d-8m');
        x=[0,14,14+243];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    elseif strcmp(Cohort,'C2a')
        Data_t=Data_Vaccine_3ug.C2a_28d_2m;
        title('C2a-28d-2m');
        x=[0,28,28+61];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    elseif strcmp(Cohort,'C2b')
        Data_t=Data_Vaccine_3ug.C2b_28d_8m;
        title('C2b-28d-8m');
        x=[0,28,28+243];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    end
    
    plot(t,R(:,3),'linewidth',2,'color',color_m);
    plot(t,R(:,2),'linewidth',2,'color',color_e);
    adjust_fig;
    xlabel('time (day)');
    %scatter(Data_t(:,1),Data_t(:,2)/scale,'filled')
    neg=(Data_t(:,2)-Data_t(:,3))/scale;
    pos=(Data_t(:,4)-Data_t(:,2))/scale;
    e =errorbar(Data_t(:,1),Data_t(:,2)/scale,neg,pos,'o','linewidth',1.5);
    e.Marker = '*';
    e.MarkerSize =5;
    e.Color = 'black';
    e.CapSize = 15;
    axis([-20 350 0 120])
end

for j=1:4
    Cohort=List{j};%%�Ĵ�
    subplot(2,4,j+4);
    if strcmp(Cohort,'C1a')
        Vaccine_I1=14;%һ������ 14  28
        Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C1b')
        Vaccine_I1=14;%һ������ 14  28
        Vaccine_I2=243;%�������� 61 243
    elseif strcmp(Cohort,'C2a')
        Vaccine_I1=28;%һ������ 14  28
        Vaccine_I2=61;%�������� 61 243
    elseif strcmp(Cohort,'C2b')
        Vaccine_I1=28;%һ������ 14  28
        Vaccine_I2=243;%�������� 61 243
    end
    y0=[Vaccine_Virus*2;0;0];%��һ��
    tspan=[0:1:Vaccine_I1-1];
    [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

    y1=R_1(end,:);%�ڶ���
    y1(1)=y1(1)+Vaccine_Virus*2;
    tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
    [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

    y2=R_2(end,:);%������
    y2(1)=y2(1)+Vaccine_Virus*2;
    tspan=[Vaccine_I1+Vaccine_I2:1:400];
    [t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
    t=[t1;t2;t3];R=[R_1;R_2;R_3];
    
    if strcmp(Cohort,'C1a')
        Data_t=Data_Vaccine_6ug.C1a_14d_2m;
    elseif strcmp(Cohort,'C1b')
        Data_t=Data_Vaccine_6ug.C1b_14d_8m;
    elseif strcmp(Cohort,'C2a')
        Data_t=Data_Vaccine_6ug.C2a_28d_2m;
    elseif strcmp(Cohort,'C2b')
        Data_t=Data_Vaccine_6ug.C2b_28d_8m;
    end
    hold on;
    if strcmp(Cohort,'C1a')
        Data_t=Data_Vaccine_6ug.C1a_14d_2m;
        x=[0,14,14+61];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
        title('C1a-14d-2m');
    elseif strcmp(Cohort,'C1b')
        Data_t=Data_Vaccine_6ug.C1b_14d_8m;
        title('C1b-14d-8m');
        x=[0,14,14+243];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    elseif strcmp(Cohort,'C2a')
        Data_t=Data_Vaccine_6ug.C2a_28d_2m;
        title('C2a-28d-2m');
        x=[0,28,28+61];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    elseif strcmp(Cohort,'C2b')
        Data_t=Data_Vaccine_6ug.C2b_28d_8m;
        title('C2a-28d-8m');
        x=[0,28,28+243];
        y=[250,250,250]; %5Ϊ��2���yֵ
        stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
    end
    
    plot(t,R(:,3),'linewidth',2,'color',color_m);
    plot(t,R(:,2),'linewidth',2,'color',color_e);
    adjust_fig;
    xlabel('time (day)');
    %scatter(Data_t(:,1),Data_t(:,2)/scale,'filled')
    neg=(Data_t(:,2)-Data_t(:,3))/scale;
    pos=(Data_t(:,4)-Data_t(:,2))/scale;
    e =errorbar(Data_t(:,1),Data_t(:,2)/scale,neg,pos,'o','linewidth',1.5);
    e.Marker = '*';
    e.MarkerSize =5;
    e.Color = 'black';
    e.CapSize = 15;
    axis([-20 350 0 120])
end
set(gcf,'position',[0 0 1500 650])

