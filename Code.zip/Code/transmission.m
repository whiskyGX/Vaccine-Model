%transmission rate
clear all;clc;
global p;
color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
model='Saturation';
%model='Power';

theta=0.2;
h=0.51;
Km=8.9e6;
fai=2.4e-5;
h2=0.53
V_log=[0:0.1:10];
V=10.^V_log;
if strcmp(model,'Saturation')
    P=1-exp(-theta*V.^h./(V.^h+Km^h));
elseif strcmp(model,'Power')
    P=1-exp(-fai*V.^h2);
end
figure;
subplot(1,4,1);
plot(V_log,P,'linewidth',2,'color',color_r);
xlabel('VL Log10 (/ml)');
ylabel('Probability of transmission');
adjust_fig;
set(gcf,'position',[100 100 380 320])
%%
p=para_Vaccine;
p(1)=0;
Vaccine_Virus=p(12);%�����е�Ч������Ŀ
scale=p(13);
Vaccine_I1=21;%һ������ 14  28
Vaccine_I2=182;%�������� 61 243

y0=[Vaccine_Virus;0;0];%��һ��
tspan=[0:1:Vaccine_I1-1];
[t1,R_1] = ode23t(@Vaccine_model,tspan,y0);

y1=R_1(end,:);%�ڶ���
y1(1)=y1(1)+Vaccine_Virus;
tspan=[Vaccine_I1:1:Vaccine_I1+Vaccine_I2-1];
[t2,R_2] = ode23t(@Vaccine_model,tspan,y1);

y2=R_2(end,:);%������
y2(1)=y2(1)+Vaccine_Virus;
tspan=[Vaccine_I1+Vaccine_I2:1:400];
[t3,R_3] = ode23t(@Vaccine_model,tspan,y2);
t=[t1;t2;t3];R=[R_1;R_2;R_3];
%% ��������
p=para_Vaccine;
ts=[0:0.1:30];
for m=1:3
    hold on;
    %{
    if m==1
        y0=[1;0;0];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        plot(t_n,log10(R_n(:,1)),'linewidth',2);
    elseif m==2
        y0=[1;R(Vaccine_I1+61,2);R(Vaccine_I1+61,3)];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        plot(t_n,log10(R_n(:,1)),'linewidth',2);
    elseif m==3
        y0=[1;R(Vaccine_I1+Vaccine_I2+61,2);R(Vaccine_I1+Vaccine_I2+61,3)];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        plot(t_n,log10(R_n(:,1)),'linewidth',2);
    end
    xlabel('time (day)');
    ylabel('VL log10 (/ml)');
    adjust_fig;
    %}
    subplot(1,4,2);
    hold on;
    if m==1
        y0=[1;0;0];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        P=1-exp(-theta*R_n(:,1).^h./(R_n(:,1).^h+Km^h));
        plot(t_n,P,'linewidth',2,'color',color_r);
    elseif m==2
        y0=[1;R(Vaccine_I1+61,2);R(Vaccine_I1+61,3)];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        P=1-exp(-theta*R_n(:,1).^h./(R_n(:,1).^h+Km^h));
        plot(t_n,P,'linewidth',2,'color',color_r);
        S=trapz(t_n,P);
        title(num2str(S));
    elseif m==3
        y0=[1;R(Vaccine_I1+Vaccine_I2+61,2);R(Vaccine_I1+Vaccine_I2+61,3)];
        [t_n,R_n] = ode23t(@Vaccine_model,ts,y0);
        P=1-exp(-theta*R_n(:,1).^h./(R_n(:,1).^h+Km^h));
        plot(t_n,P,'linewidth',2,'color',color_r);
    end
    xlabel('time (day)');
    ylabel('PoT');
    adjust_fig;
    axis([-2 30 0 0.1]);
    stem(0,1,'-.','color',[150 150 150]/255,'linewidth',2);
end


%%
Infect_time=[1:1:Vaccine_I1+Vaccine_I2+100];
R0=[];
contact=13.4;
for Infect_t=Infect_time
    y_i=R(Infect_t,:);
    y_i(1)=1;
    p=para_Vaccine;
    R_t=cal_R(y_i,contact);
    R0=[R0,R_t];
end
subplot(1,4,3)
plot(Infect_time,R0,'color',color_e,'linewidth',2);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[10,10,10]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('R_{0,i}');
axis([-20 300 0 6])
adjust_fig;

subplot(1,4,4)
plot(Infect_time,13.4./R0,'color',color_e,'linewidth',2);
hold on;
x=[0,Vaccine_I1,Vaccine_I1+Vaccine_I2];
y=[100,100,100]; %5Ϊ��2���yֵ
stem(x,y,'-.','color',[150 150 150]/255,'linewidth',2);
xlabel('time (day)');
ylabel('c');
axis([-20 300 0 50])
adjust_fig;
set(gcf,'position',[500 500 1700 320])



