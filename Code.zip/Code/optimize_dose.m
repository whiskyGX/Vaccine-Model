%optimize dose
%��Ⱦ����ģ��
clear all;clc; 
global p;
p=para_Vaccine;

color_r=[247,144,61]/255;
color_e=[254,129,125]/255;
color_m=[129,184,223]/255;
scale=p(13);
dose=[1:0.1:30];
%Interval=[14:1:30];

mVL=[];
Ht=[];
i=1;
for d=dose  
   p=para_Vaccine;
   p(1)=0;
   Vaccine_Virus=p(12)/3*d;%�����е�Ч������Ŀ 3ug
   Vaccine_I1=21;%һ������ 14  28
   y0=[Vaccine_Virus;0;0];%��һ��
   tspan=[0:1:Vaccine_I1-1];
   [t1,R_1] = ode23t(@Vaccine_model,tspan,y0);
   y1=R_1(end,:);%�ڶ���
   y1(1)=y1(1)+Vaccine_Virus;
   tspan=[Vaccine_I1:1:100];
   [t2,R_2] = ode23t(@Vaccine_model,tspan,y1);
   t=[t1;t2];R=[R_1;R_2];
   [mVL(i),Ht(i)]=cal_VL_Ht([1,R(Vaccine_I1+61,2),R(Vaccine_I1+61,3)]);
   i=i+1;
end
%%
figure;
subplot(1,2,1)
hold on;
plot(dose,log10(mVL),'b','linewidth',2);
scatter(1.5,log10(mVL(find(dose==1.5))),'filled');
scatter(3,log10(mVL(find(dose==3))),'filled');
scatter(6,log10(mVL(find(dose==6))),'filled');
scatter(9,log10(mVL(find(dose==9))),'filled');
xlabel('dose (ug)');
ylabel('MVL Log10 (/mL)');
adjust_fig;
axis([0 30 3 6])

subplot(1,2,2)
hold on;
plot(dose,Ht,'b','linewidth',2);
scatter(1.5,Ht(find(dose==1.5)),'filled');
scatter(3,Ht(find(dose==3)),'filled');
scatter(6,Ht(find(dose==6)),'filled');
scatter(9,Ht(find(dose==9)),'filled');
xlabel('dose (ug)');
ylabel('RT (day)');
adjust_fig;
set(gcf,'position',[500 500 800 320])