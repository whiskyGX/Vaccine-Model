function R0=cal_R(y_ini,C)
    global p;
    p=para_Vaccine;
    theta=0.2;
    h=0.51;
    Km=8.9e6;
    tspan=[0:0.01:30];
    [t,R] = ode23t(@Vaccine_model,tspan,y_ini);
    P=1-exp(-theta*R(:,1).^h./(R(:,1).^h+Km^h));
    S=trapz(t,P);
    R0=C*S;
end