function [mVL,Ht]=cal_VL_Ht(y_ini)
    global p;
    p=para_Vaccine;
    tspan=[0:0.01:30];
    [t,R] = ode23t(@Vaccine_model,tspan,y_ini);
    mVL=max(R(:,1));
    for i=1:length(t)-1
        if (R(i,1)>100)&&(R(i+1,1)<100)
            break;
        end
    end
    Ht=t(i+1);
end