function dydt=no_memory(t,y)
    global gamma fai r;
    dydt=zeros(2,1);
    if y(1)<0.5
        y(1) = 0;
    end
    dydt(1)=r*y(1)-gamma*y(1)*y(2); %Virus
    dydt(2)=0.0193-0.0193*y(2)+fai*y(1)/(y(1)+10^3)*y(2)*(1-y(2)/100); %Effector
    %dydt(2)=0.0193-0.0193*y(2)+fai*y(1)/(y(1)+10^3)*(1-y(2)/100);
end